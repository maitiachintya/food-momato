export const auth_Url = "http://localhost:3011/users"
export const order_Url = "http://localhost:3011/orders"
export const cart_URL = "http://localhost:3011/cart"